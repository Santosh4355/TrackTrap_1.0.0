## Submission of a new version

* This is the updated version 1.0.0, second release of TrackTrap package.
* local CPU Windows 11 install, R 4.5.2
* win-builder (devel)

### R CMD check results (devtools::check())

0 errors | 0 warnings | 0 note

* NOTE: "Possibly misspelled words in DESCRIPTION: GDD, Meteo". These are not misspellings. 'GDD' is a standard agricultural acronym for Growing Degree Days, and 'Meteo' refers to the Open-Meteo weather API used by the package.

